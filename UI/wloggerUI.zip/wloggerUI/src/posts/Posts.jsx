import React from 'react'

export default function Posts() {
  return (
    <div className='posts-container'>Posts</div>
  )
}
