import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './navbar/Navbar'
import Footer from './footer/Footer'
import LandingPage from './landingpage/LandingPage'
import {useDispatch, useSelector} from 'react-redux'
import Post from './post/Post'
import {
  createBrowserRouter,
  Outlet,
  RouterProvider,
} from "react-router-dom";
import Login from './login/Login'
import Posts from './posts/Posts'




function App() {
  
  const Layout = () => {
    return(
      <div className='app-container'>
          <Navbar />
          <Outlet />
          <Footer />
      </div>
    )
  }

  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      children:[
        {
          path:"/",
          element:<LandingPage />
        },
        {
          path:"/login",
          element:<Login/>
        },
        {
          path:"/posts",
          element:<Posts/>
        }
    ]
    },
  ]);

  const [count, setCount] = useState(0)
  const {mode} = useSelector((state) => state.darkMode);
  const dispatch = useDispatch();
  const theme = mode ? "dark" : "light";

  
  return (
    <>
      <div className={`app ${theme}`} >
        <RouterProvider router={router}/>
      </div>
    </>
  )
}

export default App
