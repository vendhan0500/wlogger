import React from 'react'
import './Post.css'

export default function Post() {
  return (
    <div className="post-container">

    </div>
  )
}
